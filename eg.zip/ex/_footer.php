<hr style="color: #f1c40f" />
<div id="backtotop">
  <ul>
    <li><a id="toTop" href="#" onClick="return false">Back to Top</a></li>
  </ul>
</div>
<!-- Start IMGSpecial -->
<div class="imgspecial">
            <img src="ex/img/standard.png" />
            <img src="ex/img/moody.png" />
            <img src="ex/img/jahad.png" />
            <img src="ex/img/iso9001.png" />
            <img src="ex/img/naci.png" />
        </div><br />
        <!-- End IMGSpecial -->
<script src="ex/js/wow.min.js" type="text/javascript"></script>
    <script>
        new WOW().init();
    </script>
<div class="footer">
    <div style="width: 100%;"></div><br />
    <div style="width: 65%; float: left; min-height: 200px; text-align: center; margin-left: 10px;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3367.5298831828554!2d51.73146218453804!3d32.43174870881619!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fbc6a7ee93867e5%3A0x483de8794cb771e2!2z2KfYtdmB2YfYp9mGINmC2LfYsdmH!5e0!3m2!1sfa!2sir!4v1469350906628" width="100%" frameborder="0" style="border: 0; min-height: 180px;" allowfullscreen></iframe>
    </div>
    <div style="width: 33%;">
        <strong><h1>پیوندهای مرتبط</h1></strong><br /><br />
        <a class="afooter" href="http://www.isiri.gov.ir/Portal/Home/"><h2>سازمان استاندارد</h2></a><br />
        <a class="afooter" href="http://ippfa.ir/"><h2>انجمن پلی اتیلن</h2></a><br />
        <a class="afooter" href="http://www.maj.ir/Portal/Home/"><h2>مرکز مکانیزاسیون آب وخاک جهاد کشاورزی</h2></a><br />
        <a class="afooter" href="http://naci.isiri.gov.ir/Portal/Home/"><h2>مرکز ملی تأیید صلاحیت ایران - NACI</h2></a><br />
    </div>
</div>
<script src="ex/js/responsive-nav.js" type="text/javascript"></script>
<script defer src="ex/js/jquery.flexslider-min.js"></script>
<script src="ex/js/jquery.fancybox.pack.js" type="text/javascript"></script>
<script src="ex/js/image-hover.js" type="text/javascript"></script>
<script src="ex/js/scrollup.js" type="text/javascript"></script>
<script src="ex/js/preloader.js" type="text/javascript"></script>
<script src="ex/js/navi-slidedown.js" type="text/javascript"></script>