<?php

$server_host = 'localhost';
$server_user = 'root';
$server_pass = '';
$server_name = 'semo';

$addres = 'http://' . $_SERVER['HTTP_HOST'] . '/eg/';