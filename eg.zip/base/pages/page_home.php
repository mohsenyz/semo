<html>
    <?php include 'ex/_head.php'; ?>
    <body>
    <!-- Start Menu -->
<?php include 'ex/_menu.php'; ?>
    <!-- End Menu -->
        <div class="logo_start">
            <img id="logo" src="ex/img/logo.png">
            <h1>اصفهان قطره</h1>
            <h3 style="margin-top: -20px;">تولید کننده انواع لوله و اتصالات پلی اتلین</h3>
        </div>
        <div class="logo_arrow"><a href="#slider" class="fa fa-arrow-down" id="arrow" aria-hidden="true"></a></div>
        <br />
        <!-- Start Slider -->
            <?php include 'ex/_slider.php'; ?>
        <!-- End Slider --><br />
    <?php include 'ex/_footer.php'; ?>
    </body>
</html>